import { NextRequest, NextResponse } from 'next/server';
import { addPaymentRequest, getDb } from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';

export async function GET() {
  const db = getDb();
  return NextResponse.json(db);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { amount, description, recipientAddress } = body;

    if (!amount || !description || !recipientAddress) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const newRequest = {
      id: uuidv4(),
      amount,
      description,
      recipientAddress,
      status: 'pending' as const,
      createdAt: Date.now(),
    };

    addPaymentRequest(newRequest);

    return NextResponse.json(newRequest);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create request' }, { status: 500 });
  }
}
