import { NextRequest, NextResponse } from 'next/server';
import { updatePaymentRequest, getDb } from '@/lib/db';
import { createPublicClient, http, parseUnits } from 'viem';
import { arcTestnet } from 'viem/chains';

const USDC_ADDRESS = "0x3600000000000000000000000000000000000000";

const client = createPublicClient({
  chain: arcTestnet,
  transport: http(),
});

export async function POST(req: NextRequest) {
  try {
    const { txHash, requestId } = await req.json();

    if (!txHash || !requestId) {
      return NextResponse.json({ error: 'Missing txHash or requestId' }, { status: 400 });
    }

    const db = getDb();
    const request = db.find(r => r.id === requestId);

    if (!request) {
      return NextResponse.json({ error: 'Request not found' }, { status: 404 });
    }

    // 1. Get receipt
    const receipt = await client.waitForTransactionReceipt({ hash: txHash as `0x${string}` });

    if (receipt.status !== 'success') {
      updatePaymentRequest(requestId, { status: 'failed', txHash });
      return NextResponse.json({ status: 'failed', message: 'Transaction failed on-chain' });
    }

    // 2. Read logs to verify USDC transfer
    // ERC-20 Transfer event signature: Transfer(address indexed from, address indexed to, uint256 value)
    const transferEventHash = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef";
    
    const usdcTransferLogs = receipt.logs.filter(log => 
      log.address.toLowerCase() === USDC_ADDRESS.toLowerCase() &&
      log.topics[0] === transferEventHash
    );

    if (usdcTransferLogs.length === 0) {
      return NextResponse.json({ error: 'No USDC transfer found in transaction' }, { status: 400 });
    }

    // Verify recipient and amount
    let verified = false;
    const expectedAmountRaw = parseUnits(request.amount, 6);
    const expectedRecipient = request.recipientAddress.toLowerCase();

    for (const log of usdcTransferLogs) {
      // topics[2] is the 'to' address
      const toAddress = `0x${log.topics[2]?.substring(26)}`.toLowerCase();
      const amount = BigInt(log.data);

      if (toAddress === expectedRecipient && amount >= expectedAmountRaw) {
        verified = true;
        break;
      }
    }

    if (verified) {
      updatePaymentRequest(requestId, { status: 'paid', txHash });
      return NextResponse.json({ status: 'paid' });
    } else {
      return NextResponse.json({ error: 'Transfer details do not match request' }, { status: 400 });
    }

  } catch (error: any) {
    console.error('Verification error:', error);
    return NextResponse.json({ error: error.message || 'Verification failed' }, { status: 500 });
  }
}
